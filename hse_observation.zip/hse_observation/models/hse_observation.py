# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from datetime import datetime


class IrAttachment(models.Model):
    _inherit = 'ir.attachment'

    observation_id = fields.Many2one('hse.observation', string="Observation")
    investigation_id = fields.Many2one('hse.observation', string="Investigation")


class HSEObservation(models.Model):
    _name = "hse.observation"
    _inherit = ['mail.thread', 'mail.activity.mixin', 'portal.mixin']

    def _inverse_operating_unit_id(self):
        for observation in self:
            observation.company_id = observation.operating_unit_id and observation.operating_unit_id.company_id.id or self.env.user.company_id.id

    name = fields.Char(
        string="Name", readonly=True,
        required=True, copy=False, index=True, default=lambda self: _('New')
    )
    full_name_observer = fields.Char(string="Full Name of Observer")
    operating_unit_id = fields.Many2one(
        'operating.unit', string="Operating Unit", inverse="_inverse_operating_unit_id"
    )
    department_id = fields.Many2one(
        'hr.department', string='Department'
    )
    company_id = fields.Many2one(
        'res.company', 'Company',
        required=True,
        default=lambda self: self.env.user.company_id.id
    )
    create_by = fields.Many2one(
        'res.users', string='Created By',
        default=lambda self: self.env.user.id, readonly=True
    )
    created_date_time = fields.Datetime(
        string="Created Date & Time", default=fields.datetime.now(),
        readonly=True
    )
    date_of_incident = fields.Date(string="Date of Incident")
    position = fields.Char(string="Position")
    location_on_site = fields.Char(string="Location on Site")
    equipment_involved = fields.Char(string="Equipment Involved")
    input_observation = fields.Text(string="Please input your observation in this box")
    officer_id = fields.Many2one('res.users', string='Officer')
    officer_datetime = fields.Datetime(
        string="Date & Time",
    )
    is_assign = fields.Boolean(string="Assign")
    root_cause_id = fields.Many2one('hse.root.cause', string='Root Cause')
    classification_id = fields.Many2one('hse.classification', string='Classification')
    risk_id = fields.Many2one('hse.risk', string='Risk Level')
    initial_cause = fields.Char(string='Initial Cause')
    findings_investigation = fields.Text(string='Findings of investigation')
    investigation_ids = fields.One2many('hse.investigation.line', 'observation_id', 
        string='Investigation Line'
    )
    observation_msg = fields.Text("Please Input Your Observation In This Box")
    state = fields.Selection([
        ('draft', 'New'),
        ('submit', 'Submit'),
        ('close', 'Close'),
    ], string="State", default="draft")
    attachment_ids = fields.One2many(
        'ir.attachment', 'observation_id',
        string='Attachments'
    )
    investigation_attachment_ids = fields.One2many(
        'ir.attachment', 'investigation_id',
        string='Attachments'
    )

    @api.multi
    def click_to_submit(self):
        for rec in self:
            rec.state = 'submit'

    @api.multi
    def click_to_close(self):
        for rec in self:
            rec.state = 'close'

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            if 'company_id' in vals:
                vals['name'] = self.env['ir.sequence'].with_context(force_company=vals['company_id']).next_by_code('hse.observation') or _('New')
            else:
                vals['name'] = self.env['ir.sequence'].next_by_code('hse.observation') or _('New')
        return super(HSEObservation, self).create(vals)

    @api.multi
    def click_to_assign(self):
        for rec in self:
            rec.officer_id = self.env.user.id
            rec.is_assign = True
            rec.officer_datetime = fields.datetime.now()
